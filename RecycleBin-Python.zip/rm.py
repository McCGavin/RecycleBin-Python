#!/usr/bin/env python3
import os
import sys


dirName = os.path.join(os.path.expanduser('~'), 'rm_trash')
numArg = len(sys.argv)

def rename(filePath): #will run when file already exists
    name,extension = os.path.splitext(filePath) #splits file.txt into file & .txt
    count = 1
    newPath = "{}-{}{}".format(name, count, extension)
    while os.path.exists(os.path.join(dirName, newPath)):
        count += 1
        newPath = "{}-{}{}".format(name, count, extension)
    return newPath


#if rm_trash does not exist, create it
if not os.path.isdir(dirName):
        print("rm_trash does not exist")
        os.mkdir(dirName)

#Move files to rm_trash, if it already exists, append -1 to the end of the file and so forth

#rm.py technically counts as an argument so skip over it

r = '-r' in sys.argv

for i in sys.argv[1:]: #runs for # of arguments
    shortName = os.path.basename(i) #shortens path to file name
    #print(shortName)
    
#----------DIRECTORY----------   
    if os.path.isdir(shortName): #check if directory
        if(r == True): #check if -r flag is active
            #check if dir exists within rm_trash
            dirTrashPath = os.path.join(dirName, shortName)#constructs the path to check inside rm_trash for dir
            if(os.access(dirTrashPath,os.F_OK)): #checks if directory exists within rm_trash
                print("dir exists within rm_trash, renaming")
                newDirTrashPath = rename(shortName)
                os.system('mv {} {}'.format(shortName,newDirTrashPath))#Renames directory
                os.system('mv {} {}'.format(newDirTrashPath,dirName))#moves directory to rm_trash
            else:
                os.system('mv {} {}'.format(shortName, dirName))
        else: # r is false
            print("rm.py: cannot remove '"+shortName+"': Is a directory")

    else:
#----------FILE----------
        if not(os.access(shortName, os.F_OK)): #if arg file does not exist
            if not(shortName == '-r'):
                print("rm.py: cannot remove '" + shortName + "': no such file or directory")
        else: #arg file does indeed exist
            #check to see if i already exists inside of rm_trash
    
            trashPath = os.path.join(dirName, shortName) #constructs the path to check inside rm_trash
    
            if(os.access(trashPath, os.F_OK)): #file exists within rm_trash
                #print("file exists, renaming")
                newTrashPath = rename(shortName)
                os.system('mv {} {}'.format(shortName,newTrashPath)) #renames the actual file
                os.system('mv {} {}'.format(newTrashPath,dirName)) #moves renamed file
            else:
                os.system('mv {} {}'.format(shortName, dirName))
