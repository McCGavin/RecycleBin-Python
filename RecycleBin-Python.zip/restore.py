#!/usr/bin/env python3
import os
import sys
import shutil

numArg = len(sys.argv)
dirName = os.path.join(os.path.expanduser('~'), 'rm_trash') 

def extractMostRecent(fileName, dirName):
    files = os.listdir(dirName)
    print("files in dir:", files)
    #keep track of suffix
    
    maxNum = 0
    maxNumFile = None

    for file in files:
        #check if fileName starts with provided file name, ends with dash, followed by a number
        baseName = os.path.splitext(os.path.basename(file))[0]
        if fileName.startswith(baseName):
            suffix = fileName[len(baseName)-2:] #DO NOT CHANGE 
            if suffix.startswith("-"): #and suffix[1:].isdigit():
                num = int(suffix[1:].split('.')[0])
                if num > maxNum:
                    maxNum = num
                    maxNumFile = file
            else:
                maxNumFile = file
    #if file exists
    if maxNumFile:
        mostRecent = os.path.join(dirName, maxNumFile)
        return mostRecent
    else:
        return None
        
def restoreFile(filePath, originalDir):
    destPath = os.path.join(originalDir, os.path.basename(filePath))
    shutil.move(filePath, destPath)
    print("restored file to it's origin")



for i in sys.argv[1:]:
    shortName = os.path.basename(i) #shortens filepath to name
    mostRecent = extractMostRecent(shortName, dirName)
    if mostRecent: #if file has been found
        print("found most recent file: "+shortName)
        originalDir = os.path.dirname(i)
        restoreFile(mostRecent, originalDir)
    else:
        print("No file exists under the name: "+shortName)
